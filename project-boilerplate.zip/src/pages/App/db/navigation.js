module.exports=[
  {
    "id":1,
    "content": "<a href=google.com>Početna</a>",
    "active": "true",
  },
  {
    "id": 2,
    "content": "<a href=\"/Home\">Cuganje</a>",
  },
  {
    "id": 3,
    "content": "<a href=\"/Favorites\">Najdraže</a>",
    "active": "false",
  },
  {
    "id": 4,
    "content": "<a href=\"/Cart\">Plati pa idemo</a>",
  },
  {
    "id": 5,
    "content": "<a href=\"/About/\">About as</a>",
  }
];
