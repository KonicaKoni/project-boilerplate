export { default as Home } from './Home';
export { default as NotFound } from './NotFound';
export { default as About } from './About';
export { default as App } from './App';
export { default as Favorites } from './Favorites';
export { default as Cart } from './Cart';
